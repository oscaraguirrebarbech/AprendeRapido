from flask import Flask, request, jsonify
from flask_cors import CORS
import mercadopago

app = Flask(__name__)
CORS(app)

ACCESS_TOKEN = "TEST-xxxxxxxxxxxxxxxxxxxxxxxxxxxxxx"  # Reemplaza con tu token real
sdk = mercadopago.SDK(ACCESS_TOKEN)

@app.route('/webhook-paypal', methods=['POST'])
def webhook_paypal():
    data = request.json
    nombre = data.get('nombre')
    email = data.get('email')
    producto = data.get('producto')

    if nombre and email and producto:
        print(f"✅ {nombre} compró {producto}. Enviando a {email}...")

        mensaje_email = f"""
        Hola {nombre},\n\n
        Gracias por comprar "{producto}".\n
        Aquí tienes tu enlace de descarga: https://tuweb.com/descargas/{producto.replace(' ', '_')}.pdf\n\n
        ¡Disfrútalo!\n
        -- Equipo de MiTienda
        """
        print(mensaje_email)

        return jsonify({"mensaje": "Pago verificado. Producto enviado."}), 200
    else:
        return jsonify({"error": "Datos incompletos."}), 400

@app.route('/crear-preferencia', methods=['POST'])
def crear_preferencia():
    data = request.get_json()
    nombre = data.get("nombre")
    email = data.get("email")
    producto = data.get("producto")
    precio = float(data.get("precio"))

    if not all([nombre, email, producto, precio]):
        return jsonify({"error": "Datos incompletos"}), 400

    preference_data = {
        "items": [
            {
                "title": producto,
                "quantity": 1,
                "currency_id": "USD",
                "unit_price": precio
            }
        ],
        "payer": {
            "name": nombre,
            "email": email
        },
        "back_urls": {
            "success": "https://tusitio.com/gracias",
            "failure": "https://tusitio.com/error",
            "pending": "https://tusitio.com/pendiente"
        },
        "auto_return": "approved",
        "notification_url": "https://tusitio.com/webhook-mercadopago"
    }

    preference_response = sdk.preference().create(preference_data)
    return jsonify(preference_response["response"])

@app.route('/')
def index():
    return "Servidor de pagos funcionando."

if __name__ == '__main__':
    app.run(debug=True, port=5000)