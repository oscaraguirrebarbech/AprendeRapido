from flask import Flask, request, jsonify
from flask_cors import CORS

app = Flask(__name__)
CORS(app)

@app.route('/webhook-paypal', methods=['POST'])
def webhook_paypal():
    data = request.json
    nombre = data.get('nombre')
    email = data.get('email')
    producto = data.get('producto')

    if nombre and email and producto:
        print(f"✅ {nombre} compró {producto}. Enviando a {email}...")

        mensaje_email = f"""
        Hola {nombre},\n\n
        Gracias por comprar "{producto}".\n
        Aquí tienes tu enlace de descarga: https://tuweb.com/descargas/{producto.replace(' ', '_')}.pdf\n\n
        ¡Disfrútalo!\n
        -- Equipo de MiTienda
        """
        print(mensaje_email)

        return jsonify({"mensaje": "Pago verificado. Producto enviado."}), 200
    else:
        return jsonify({"error": "Datos incompletos."}), 400

@app.route('/')
def index():
    return "Servidor de pagos funcionando."

if __name__ == '__main__':
    app.run(debug=True, port=5000)